Title: Medical Diagnostic System
Description: Medical Diagnostic system for heart diseases is an expert system built using java and Knowledgewright by Amzi Inc. It helps to detect wether a person is suffering from a heart disease. The conclusion is calculated after the user answers to some questions. The program then searches through the knowledgebase and as per the rules and facts, it comes up with a conclusion. it all contains some relevant information on the three heart diesease that it focuses on. It uses a Heuristic search and follows the forward chaining principle.
please read the "read me" file in the archive before running the application. if you like this application than vote for it :) 
NB
Most of the information is taken down from the internet and there was no intention for duplication. iam sorry if anyone gets offended, please let me know. Thanx to Amzi Inc and to the developers of the oalnf look and feel, you people are just great.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=3293&lngWId=2

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
