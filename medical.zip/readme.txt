This is a rule based expert system whose main engine runs on knowledgewright by Amzi Inc. Please do not delete the accompanying files as they are the files that help us to connect to  the knowledge base. Please do not hesitate to contact me for any enquiries.

Remember to set the oalnf.jar package in the classpath when compiling the program. Thanx to OALNF for providing suxh a wonderful look and feel.


ODBC Data Source name is : AI
database: AI.mbd (microsoft access)

